from django.test import TestCase

# Create your tests here.
list = []
list.append([1,2,23,4,5])
list.append([7,8,23,67,6])
print(list)