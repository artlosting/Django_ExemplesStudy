from django.db import models

# Create your models here.
class Grades(models.Model):
    gname = models.CharField(max_length=20)
    gdate = models.DateTimeField()
    ggirlnum = models.IntegerField(default=True)
    gboynum = models.IntegerField()
    isDelete = models.BooleanField(default=False)
    def __str__(self):
    	return self.gname
    class Meta:
        db_table = "grades"
        ordering = ['id']

class StudentsManager(models.Manager):
    def get_queryset(self):
        return super(StudentsManager, self).get_queryset().filter(isDelete=False)
    def createStudent2(self, name, gender, age, content, grade, isDel = False):
        stu = self.model()
        stu.sname = name
        stu.sgender = gender
        stu.sage = age
        stu.scontent = content
        stu.sgrade = grade
        #print(type(stu))
        return stu

class Students(models.Model):
    # 添加一个学生
    @classmethod
    def createStudent(cls, name, gender, age, content, grade, isDel = False):
        stu = cls(sname = name, sage = age, sgender = gender, scontent = content, sgrade = grade, isDelete = isDel)
        return stu
    # 自定义模型管理器
    stuObj = StudentsManager()

    # 定义表字段属性
    sname = models.CharField(max_length=20)
    sgender = models.BooleanField(default=False)
    sage = models.IntegerField()
    scontent = models.CharField(max_length=20)
    # 关联外键，将外键定义在多的类里面
    sgrade = models.ForeignKey("Grades")
    isDelete = models.BooleanField(default=False)
    def __str__(self):
        return self.sname

    # 定义元信息
    class Meta:
        db_table = "students" # 表的名字
        ordering = ["id"]  # 表的外键升序 #["-id"]降序