from django.contrib import admin


# Register your models here.
from .models import Grades,Students


class StudentsInfor(admin.TabularInline):
    model = Students
    extra = 2

class GradesAdmin(admin.ModelAdmin):
    inlines = [StudentsInfor]

    #列表页属性
    list_display = ['pk','gname','gdate','ggirlnum','gboynum']
    list_filter = ['gname']
    search_filter = ['gname']
    list_per_page = 5
    #添加，修改页属性
    #fields = ['ggirlnum','gboynum','gdate','isDelete']
    fieldsets = [
        ("num",{"fields":['ggirlnum','gboynum']}),

        ("base",{"fields":['gname','gdate','isDelete']}),
    ]

# @admin.register(Students)
class StudentsAdmin(admin.ModelAdmin):
    def gender(self):
        if self.sgender:
            return "男"
        else:
            return "女"
    gender.short_description = "性别"
    actions_on_bottom = True
    actions_on_top = False
    #列表页属性
    list_display = ['pk','sname',gender,'scontent','sgrade']
    search_filter = ['sname']
    list_per_page = 5
    #添加，修改页属性

admin.site.register(Grades, GradesAdmin)
admin.site.register(Students, StudentsAdmin)