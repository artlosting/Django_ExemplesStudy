from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^$',views.index),
    url(r'^(\d+)/(\d+)/$', views.detail),
    url(r'^grades/$', views.grades),
    url(r'^students/$', views.students),
    url(r'^grades/(\d+)$', views.studentsByclass),
    url(r'^addstudents/$', views.addStudents),
    url(r'^addstudents2/$', views.addStudents2),
    url(r'^testget/$', views.getTest),
    url(r'^register/$', views.register),
    url(r'^registerProcess/$', views.registerProcess),

    url(r'^home/$', views.home, name="home"),
    url(r'^login/$', views.login, name="login"),
    url(r'^quit/$', views.quit, name="quit"),
    url(r'^loginProcess/$', views.loginProcess, name="loginProcess"),
    url(r'^upfile/$', views.upfile, name="upfile"),
    url(r'^upfile/upfileProcess/$', views.upfileProcess, name="upfileProcess"),
    url(r'^showImage/$', views.showImage, name="showImage"),
    url(r'^studentsPage/(\d+)/$', views.studentsPage, name="studentsPage"),

    url(r'^ajaxstu/$', views.ajaxstu, name="ajaxstu"),
    url(r'^studentsinfor/$', views.studentsInfor),

]