from django.shortcuts import render
from django.core.urlresolvers import reverse
# Create your views here.
from django.http import JsonResponse
from django.http import HttpResponse


def index(request):
	return HttpResponse("这是我的第二个django")

def detail(request, num1, num2):
	return HttpResponse("detail-%s-%s"%(num1,num2))

from .models import  Grades,Students
def grades(request):
	# 从模型中取数据
	gradesList = Grades.objects.all()
	# 将数据传给模板
	return render(request,'people/grades.html',{"grades":gradesList})

def students(request):
	# 从模型中取数据
	#studentsList = Students.objects.all()
	#studentsList = Students.stuObj.all()[0:5]
	studentsList = Students.stuObj.all()
	# 将数据传给模板
	return render(request,'people/students.html',{"students":studentsList})

def studentsByclass(request, num):
	grade = Grades.objects.get(pk=num)
	studentsList = grade.students_set.all()
	return render(request, 'people/students.html', {"students": studentsList})

def addStudents(request):
	grade = Grades.objects.get(pk=1)
	stu = Students.createStudent("小樱",False, 15,  "我是纲手的徒弟", grade)
	stu.save()
	return HttpResponse("添加成功")

def addStudents2(request):
	grade = Grades.objects.get(pk=1)
	stu = Students.stuObj.createStudent2("静因",False, 15,  "我是纲手的徒弟，小樱的师姐", grade)
	stu.save()
	return HttpResponse("添加成功，OK！")

def getTest(request):
	a = request.GET.getlist("a")
	a1 = a[0]
	a2 = a[1]
	b = request.GET.get("b")
	print(request.path)
	print(request.session)
	print(request.POST)
	print(request.GET)
	print(request.encoding)
	print(request.method)
	return HttpResponse(a1 +" "+ b +" "+ a2)

def register(request):
	return render(request,'people/register.html')

def registerProcess(request):
	name = request.POST.get("name")
	age = request.POST.get("age")
	gender = request.POST.get("gender")
	print(name)
	return HttpResponse(name + " "+ age +" "+ gender)

from django.shortcuts import redirect

def redirect1(request):
#    return HttpResponseRedirect('/redirect2')
      return redirect('/redirect2')

def redirect2(request):
      return HttpResponse("我是重定向后的视图")

def home(request):
	# 接受session
	username = request.session.get("name","亲")
	nameid = request.session.get("nameid")
	return render(request, 'people/home.html', {'username':username,'nameid':nameid})

def login(request):
	return render(request, 'people/login.html')

def loginProcess(request):
	# 存储session
	request.session['name'] = request.POST.get("username")
	# 设置session过期时间为5秒
	request.session.set_expiry(100)
	request.session['nameid'] = 1
	return redirect(reverse('app:home'))
	#return redirect('/home')

# 退出登录
from django.contrib.auth import logout
def quit(request):
	logout(request)
	return render(request, 'people/home.html')

def upfile(request):
	return render(request,'people/upfile.html')

import os
from django.conf import settings
def upfileProcess(request):
	# 判断是否为POST请求
	if request.method == "POST":
		# 接收文件流
		f = request.FILES["upfile"]
		# 设置文件路径
		print(f.name)
		filePath = os.path.join(settings.MEDIA_ROOT, f.name)
		# 开始在指定的路径转存文件流
		with open(filePath, 'wb') as fp:
			for info in  f.chunks():
				fp.write(info)

		# 将文件的名字存在session中，在重定向中取出名字，显示在网页中
		request.session['name'] = f.name

		return redirect('/showImage')
	else:
		return HttpResponse("上传失败！！！请重新上传。")

def showImage(request):
	# 接受session
	filename = request.session.get("name")
	#return HttpResponse(filename + "000000000000000000000")
	return render(request, 'people/showimage.html', {'filename':filename})

from django.core.paginator import Paginator
def studentsPage(request, pageid):
	# 获取所有学生列表
	allList = Students.stuObj.all()
	# 获得分页后的一个子对象
	paginator = Paginator(allList, 10)
	# 每一页的内容
	page = paginator.page(pageid)
	return render(request, 'people/studentspage.html', {"students": page})

# ajax例子
def ajaxstu(request):
	return render(request, 'people/ajaxstu.html')

def studentsInfor(request):
	# 获取学生信息
	stus = Students.stuObj.all()
	list = []
	for stu in stus:
		list.append([stu.sname, stu.sage, stu.scontent])

	return JsonResponse({"data": list})
