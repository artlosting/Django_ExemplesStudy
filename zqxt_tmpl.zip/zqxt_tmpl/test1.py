from django.test import TestCase

# Create your tests here.
import os
import django
os.environ.setdefault('DJANGO_SETTING_MODULE', 'zqxt_tmpl.settings')
django.setup()

from people.models import Grades,Students
from django.utils import timezone
from datetime import *
print(Grades.objects.get(pk=1))