$(document).ready(function(){
console.log("000000000000000000000000")
    document.getElementById("btn").onclick = function(){
        console.log("111111111111111111111111111111")
        $.ajax({
            type:"get",
            url:"/studentsinfor/",
            dataType:"json",
            success:function(data, status){
                console.log(data)
                var d = data["data"]
                for(var i=0; i<d.length; i++){
                    for(var j=0; j<d[i].length; j++)
                        document.write('<p>'+d[i]+'</p>')
                }
            }

        })
    }


})